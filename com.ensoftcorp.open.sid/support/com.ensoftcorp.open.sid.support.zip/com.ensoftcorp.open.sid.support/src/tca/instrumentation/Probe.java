package tca.instrumentation;

public interface Probe {

}
